import { useState } from 'react'
import reactLogo from './assets/react.svg'
import viteLogo from '/vite.svg'
import './App.css'
import { Ecomm } from './Components/Ecomm'

function App() {

  return (
    <>
      <Ecomm/>
    </>
  )
}

export default App
