// Import the functions you need from the SDKs you need
import { initializeApp } from "firebase/app";
// TODO: Add SDKs for Firebase products that you want to use
// https://firebase.google.com/docs/web/setup#available-libraries

// Your web app's Firebase configuration
const firebaseConfig = {
  apiKey: "AIzaSyDifaxQNAFbUhA5WlpUY5dAQ6UClUPySEo",
  authDomain: "e-commerce-59b69.firebaseapp.com",
  projectId: "e-commerce-59b69",
  storageBucket: "e-commerce-59b69.firebasestorage.app",
  messagingSenderId: "497760677143",
  appId: "1:497760677143:web:a96ad56ce39f5039b91b52",
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
